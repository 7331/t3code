export interface RangeBounds {
    start: number;
    end: number;
}
//# sourceMappingURL=rangeBounds.d.ts.map