export declare const ENRM_INPUT_CLASS = "enrm-input";
export declare const ENRM_INPUT_SELECTION_VAR = "--enrm-input-selection-bg";
export declare function injectInputStyles(): void;
//# sourceMappingURL=inputStyles.d.ts.map