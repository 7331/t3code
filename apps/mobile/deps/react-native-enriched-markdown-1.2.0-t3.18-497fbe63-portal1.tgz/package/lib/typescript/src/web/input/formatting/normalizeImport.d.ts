import { type BlockRange } from '../model/blocks';
import type { FormattingRange } from '../model/inlineStyles';
export declare function normalizeFormattingRanges(ranges: readonly FormattingRange[]): FormattingRange[];
export declare function normalizeBlockRanges(text: string, blocks: readonly BlockRange[]): BlockRange[];
//# sourceMappingURL=normalizeImport.d.ts.map