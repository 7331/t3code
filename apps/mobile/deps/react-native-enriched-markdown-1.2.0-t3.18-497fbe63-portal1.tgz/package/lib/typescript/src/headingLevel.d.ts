import type { HeadingLevel } from './types/MarkdownTextInputInstance';
export declare function toHeadingLevel(level: number): HeadingLevel;
//# sourceMappingURL=headingLevel.d.ts.map