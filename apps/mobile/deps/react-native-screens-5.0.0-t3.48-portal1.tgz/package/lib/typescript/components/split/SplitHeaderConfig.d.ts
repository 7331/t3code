import React from 'react';
declare const _default: React.ForwardRefExoticComponent<import("../stack").StackHeaderConfigProps & React.RefAttributes<import("../stack").StackHeaderConfigRef>>;
export default _default;
//# sourceMappingURL=SplitHeaderConfig.d.ts.map