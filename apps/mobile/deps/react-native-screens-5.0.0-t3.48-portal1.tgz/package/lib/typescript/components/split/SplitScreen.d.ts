import React from 'react';
import { SplitScreenProps, SplitStackProps } from './SplitScreen.types';
/**
 * Index of the column assigned by `Split.Host` to each `Split.Column`; read by the screens of the column.
 */
export declare const SplitColumnIndexContext: React.Context<number>;
/**
 * EXPERIMENTAL API, MIGHT CHANGE W/O ANY NOTICE
 *
 * A screen in the navigation stack of a column.
 */
declare function Screen(props: SplitScreenProps): React.JSX.Element;
/**
 * EXPERIMENTAL API, MIGHT CHANGE W/O ANY NOTICE
 *
 * The navigation stack of a column. It has no native counterpart: its screens are mounted directly in the host and
 * routed to the column by index.
 */
declare function Stack(props: SplitStackProps): React.JSX.Element;
/**
 * EXPERIMENTAL API, MIGHT CHANGE W/O ANY NOTICE
 *
 * A column. With a `Split.Stack` child it is a JS-only grouping of the stack's screens and must not have other
 * children; otherwise the column itself is a single screen.
 */
declare function Column(props: SplitScreenProps): React.JSX.Element;
/**
 * EXPERIMENTAL API, MIGHT CHANGE W/O ANY NOTICE
 */
declare function Inspector(props: SplitScreenProps): React.JSX.Element;
/**
 * EXPERIMENTAL API, MIGHT CHANGE W/O ANY NOTICE
 */
declare const SplitScreen: {
    Column: typeof Column;
    Stack: typeof Stack;
    Screen: typeof Screen;
    Inspector: typeof Inspector;
};
export default SplitScreen;
//# sourceMappingURL=SplitScreen.d.ts.map